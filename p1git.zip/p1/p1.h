//
// Created by angela on 22/10/24.
//

#ifndef P1_H
#define P1_H

//LIBRERÍAS IMPLEMENTADAS
#include <stdio.h>
#include "historial.h"
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <time.h>
#include <pwd.h>
#include <grp.h>
#include <sys/utsname.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <dirent.h>

//CONSTANTES DEFINIDAS
#define MAX 1024 //maximo de letras en una palabra
#define MAXPROGRAM 4096 //maximos de elementos de la lista estática

//COMANDOS P1
void makefile(char *trozos[]);
void makedir();
void cwd();
void listfile();
void listdir();
void reclist();
void revlist();
void erase();
void delrec();


#endif //P1_H
